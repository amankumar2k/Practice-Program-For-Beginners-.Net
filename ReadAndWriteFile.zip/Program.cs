﻿using ReadAndWrite;

namespace ReadWriteFile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WriteFile obj = new WriteFile();

            Console.WriteLine("Enter the Content Which u want to write into a file");
            obj.Content = Console.ReadLine();
            obj.FilePath = "content.txt";
            WriteFile.WriteContent(obj.FilePath, obj.Content);
            


            ReadFile obj1 = new ReadFile();

            Console.WriteLine("Enter the path");
            obj1.FilePath = Console.ReadLine();

            try
            {
                ReadFile.PrintErrorContent(obj1.FilePath);
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine($"The Error is that:{ex.Message}");
            }
            
            finally
            {
                Console.ReadKey();
            }

        }
    }
}