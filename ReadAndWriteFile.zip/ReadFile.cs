﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadAndWrite
{
    public class ReadFile
    {
        public string FilePath;

        public static void PrintErrorContent(string FilePath)
        {
            var line = File.ReadAllLines(FilePath);
            int count = 0;
            foreach (var lines in line)
            {
                Console.WriteLine(line);

                if (line.Contains("error"))
                {
                    count++;
                }
            }
            Console.WriteLine("The Number of errors:  " + count);
        }
        
        }
    }

