﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace ReadAndWrite
{
    public class WriteFile
    {
        public string FilePath;
        public string Content;
        public static void WriteContent(string FilePath, string Content)
        {
            using (StreamWriter writer= new StreamWriter(FilePath, true))
            {
                writer.WriteLine($"Time of Occured:  {DateTime.Now}");
                writer.WriteLine($" The Content: {Content}");
                Console.WriteLine("Enter Your Age");
                int age=Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("The Content is written on: " + FilePath);
        }
    }
}
