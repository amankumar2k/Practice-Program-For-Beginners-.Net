﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankDetailsProject
{
    internal class Bank
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public void AddCustomer(Customer customer)
        {
            Console.WriteLine("Customer Added\n");
            Console.WriteLine("Customer Added\n");

        }
        public void RemoveCustomer(Customer customer)
        {
            Console.WriteLine("Customer Removed\n");
        }
    }
}
