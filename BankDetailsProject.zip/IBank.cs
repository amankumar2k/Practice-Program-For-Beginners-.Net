﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankDetailsProject
{
    internal interface IBank
    {
        void AddCustomer(Customer customer);
        void RemoveCustomer(Customer customer);
    }
}
