﻿using System;
namespace BankDetailsProject
{
    class BankDetails
    {
        static void Main(string[] args)
        {
            Customer customer = new Customer();
            customer.CustomerId = 1;
            customer.Name = "Test";
            customer.Address = "mysore";
            customer.PhoneNumber = "1234567890";
            customer.Acounts = "Saving";

            Bank bank = new Bank();
            bank.ID = 1;
            bank.Name = "Test1";

            Account account = new Account();
            account.AccountNumber = 123456;
            account.Balance = 100;

        }
    }
}