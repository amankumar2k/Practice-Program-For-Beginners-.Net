﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankDetailsProject
{
    internal class Account
    {
        public int AccountNumber { get; set; }
        public int Balance { get; set; }

        public Account() 
        {
            Balance = 1;
            AccountNumber = AccountNumber;
        }

        public void Deposit(decimal amount)
        {
            if (Balance> 0) 
            {
                Console.WriteLine("You Can Deposite");

            }
        }
        public void Withdraw(decimal amount)
        {
            if (Balance < 0)
            {
                Console.WriteLine("There Is No Amount");
            }
            else
                Console.WriteLine("Not Withdrawn");
        }

        public void CalculateInterest()
        {
            double interest = Balance * 1.2 ;

        }

    }
}
